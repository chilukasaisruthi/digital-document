# Digital Document Management System – C. Sai Sruthi

A full-stack college mini project using HTML, CSS, JavaScript, Express.js and MySQL.

## Project description
Store and manage digital documents in an organized manner. Users can upload documents, categorize them, search documents, download files and manage document access.

## Database
Database name: `digital_documents`

### Table 1: users
- `user_id` INT PRIMARY KEY AUTO_INCREMENT
- `name` VARCHAR(100)
- `email` VARCHAR(100) UNIQUE
- `password` VARCHAR(255) (hashed password)
- `role` VARCHAR(20)

### Table 2: categories
- `category_id` INT PRIMARY KEY AUTO_INCREMENT
- `category_name` VARCHAR(100)
- `description` VARCHAR(255)

### Table 3: documents
- `document_id` INT PRIMARY KEY AUTO_INCREMENT
- `user_id` INT FOREIGN KEY
- `category_id` INT FOREIGN KEY
- `title` VARCHAR(150)
- `file_name` VARCHAR(255)
- `upload_date` DATETIME
- `status` VARCHAR(20)

### Table 4: document_access
- `access_id` INT PRIMARY KEY AUTO_INCREMENT
- `document_id` INT FOREIGN KEY
- `user_id` INT FOREIGN KEY
- `permission` VARCHAR(20)
- `granted_date` DATETIME

Note: The project uses `title` (rather than the likely typing error `tittle`) and `DATETIME` for date-and-time fields.

## Main features
1. Register and login.
2. Upload documents (PDF, DOC, DOCX, TXT, PNG, JPG; maximum 10 MB).
3. Categorize documents.
4. Search by title or category and filter by category.
5. Download documents when permission allows.
6. Share documents with registered users using `view` or `download` permission.
7. Remove shared access.
8. Delete your own documents.

## Run on your computer (Windows + VS Code)
1. Install Node.js and MySQL Server.
2. Open MySQL Workbench, open `db.sql`, and execute the whole script.
3. Extract this ZIP and open the extracted project folder in VS Code.
4. In VS Code, choose Terminal > New Terminal.
5. Run `npm install`.
6. Make a copy of `.env.example` and name the copy `.env`.
7. Open `.env`. Enter your MySQL password after `DB_PASSWORD=`. If root has no password, leave it blank. Keep the other settings as they are for a normal local setup.
8. Run `npm start`.
9. Open Chrome and visit `http://localhost:3000`.
10. Choose Create account, register, and start uploading documents.

## Make the first account an admin (optional)
After registering your account, run this SQL in MySQL Workbench, replacing the email with your registered email:
```sql
USE digital_documents;
UPDATE users SET role = 'admin' WHERE email = 'your-email@example.com';
```
Log out and log in again. Admin can see all active documents and manage access/deletion.

## Upload to GitHub
Create a new empty GitHub repository named `digital-document-management-system-c-sai-sruthi`.
In the VS Code terminal, from this project folder, run:
```bash
git init
git add .
git commit -m "Digital Document Management System - C. Sai Sruthi"
git branch -M main
git remote add origin https://github.com/YOUR-GITHUB-USERNAME/digital-document-management-system-c-sai-sruthi.git
git push -u origin main
```
Replace `YOUR-GITHUB-USERNAME` with your own GitHub username. Never upload `.env`, real passwords, or private documents. The `.gitignore` excludes them.

## Important
This is a local college-project starter, not a production-ready document platform. For public deployment, use a production session store, HTTPS, CSRF protection, stricter file-content validation, and additional security review.
