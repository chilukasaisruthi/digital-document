require("dotenv").config();
const express = require("express");
const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "digital_documents",
  waitForConnections: true,
  connectionLimit: 10
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "local-demo-secret-change-this",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", maxAge: 1000 * 60 * 60 * 3 }
}));
app.use(express.static(path.join(__dirname, "public")));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_"))
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /\.(pdf|doc|docx|txt|png|jpg|jpeg)$/i.test(file.originalname);
    cb(ok ? null : new Error("Allowed files: PDF, DOC, DOCX, TXT, PNG and JPG."), ok);
  }
});

function loggedIn(req, res, next) {
  if (!req.session.user) return res.status(401).json({ message: "Please login first." });
  next();
}
function isAdmin(req) { return req.session.user && req.session.user.role === "admin"; }

async function canAccess(documentId, user) {
  const [rows] = await pool.query(
    `SELECT d.*, c.category_name, u.name AS owner_name,
      CASE WHEN d.user_id = ? OR ? = 'admin' THEN 'manage'
           ELSE da.permission END AS my_permission
     FROM documents d
     JOIN categories c ON c.category_id = d.category_id
     JOIN users u ON u.user_id = d.user_id
     LEFT JOIN document_access da ON da.document_id = d.document_id AND da.user_id = ?
     WHERE d.document_id = ? AND d.status = 'active'
       AND (d.user_id = ? OR ? = 'admin' OR da.user_id = ?)`,
    [user.user_id, user.role, user.user_id, documentId, user.user_id, user.role, user.user_id]
  );
  return rows[0] || null;
}

app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.post("/api/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 6)
      return res.status(400).json({ message: "Enter name, email and a password of at least 6 characters." });
    const hash = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
      "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')",
      [name.trim(), email.trim().toLowerCase(), hash]
    );
    req.session.user = { user_id: result.insertId, name: name.trim(), email: email.trim().toLowerCase(), role: "user" };
    res.status(201).json({ message: "Account created successfully.", user: req.session.user });
  } catch (err) {
    res.status(400).json({ message: err.code === "ER_DUP_ENTRY" ? "This email is already registered." : "Registration failed." });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const email = (req.body.email || "").trim().toLowerCase();
    const [rows] = await pool.query("SELECT * FROM users WHERE email = ?", [email]);
    if (!rows.length || !(await bcrypt.compare(req.body.password || "", rows[0].password)))
      return res.status(401).json({ message: "Incorrect email or password." });
    const u = rows[0];
    req.session.user = { user_id: u.user_id, name: u.name, email: u.email, role: u.role };
    res.json({ message: "Login successful.", user: req.session.user });
  } catch { res.status(500).json({ message: "Login failed. Check database connection." }); }
});

app.post("/api/logout", loggedIn, (req, res) => {
  req.session.destroy(() => res.json({ message: "Logged out." }));
});

app.get("/api/categories", loggedIn, async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM categories ORDER BY category_name");
    res.json(rows);
  } catch { res.status(500).json({ message: "Could not load categories." }); }
});

app.get("/api/documents", loggedIn, async (req, res) => {
  try {
    const search = `%${req.query.search || ""}%`;
    const categoryId = req.query.category || "";
    const [rows] = await pool.query(
      `SELECT d.document_id, d.user_id, d.category_id, d.title, d.file_name,
              d.upload_date, d.status, c.category_name, u.name AS owner_name,
              CASE WHEN d.user_id = ? OR ? = 'admin' THEN 'manage' ELSE da.permission END AS my_permission
       FROM documents d
       JOIN categories c ON c.category_id = d.category_id
       JOIN users u ON u.user_id = d.user_id
       LEFT JOIN document_access da ON da.document_id = d.document_id AND da.user_id = ?
       WHERE d.status = 'active'
         AND (d.user_id = ? OR ? = 'admin' OR da.user_id = ?)
         AND (d.title LIKE ? OR c.category_name LIKE ?)
         AND (? = '' OR d.category_id = ?)
       ORDER BY d.upload_date DESC`,
      [req.session.user.user_id, req.session.user.role, req.session.user.user_id,
       req.session.user.user_id, req.session.user.role, req.session.user.user_id,
       search, search, categoryId, categoryId]
    );
    res.json(rows);
  } catch { res.status(500).json({ message: "Could not load documents." }); }
});

app.post("/api/documents", loggedIn, upload.single("document"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: "Choose a file to upload." });
    const { title, category_id } = req.body;
    if (!title || !category_id) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ message: "Title and category are required." });
    }
    const [result] = await pool.query(
      "INSERT INTO documents (user_id, category_id, title, file_name, upload_date, status) VALUES (?, ?, ?, ?, NOW(), 'active')",
      [req.session.user.user_id, category_id, title.trim(), req.file.filename]
    );
    res.status(201).json({ message: "Document uploaded successfully.", document_id: result.insertId });
  } catch (err) {
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    res.status(500).json({ message: "Upload failed. Check the category and database." });
  }
});

app.get("/api/documents/:id/download", loggedIn, async (req, res) => {
  try {
    const doc = await canAccess(req.params.id, req.session.user);
    if (!doc) return res.status(404).json({ message: "Document not found or you do not have access." });
    if (!["download", "manage"].includes(doc.my_permission))
      return res.status(403).json({ message: "You have view-only permission for this document." });
    const filePath = path.join(uploadDir, doc.file_name);
    if (!fs.existsSync(filePath)) return res.status(404).json({ message: "Stored file is missing." });
    res.download(filePath, doc.file_name.replace(/^\d+-/, ""));
  } catch { res.status(500).json({ message: "Download failed." }); }
});

app.delete("/api/documents/:id", loggedIn, async (req, res) => {
  try {
    const doc = await canAccess(req.params.id, req.session.user);
    if (!doc) return res.status(404).json({ message: "Document not found or you do not have access." });
    if (doc.my_permission !== "manage") return res.status(403).json({ message: "Only the owner or admin can delete this document." });
    await pool.query("DELETE FROM documents WHERE document_id = ?", [req.params.id]);
    const filePath = path.join(uploadDir, doc.file_name);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    res.json({ message: "Document deleted." });
  } catch { res.status(500).json({ message: "Delete failed." }); }
});

app.get("/api/documents/:id/access", loggedIn, async (req, res) => {
  try {
    const doc = await canAccess(req.params.id, req.session.user);
    if (!doc || doc.my_permission !== "manage") return res.status(403).json({ message: "Only the owner or admin can manage access." });
    const [rows] = await pool.query(
      `SELECT da.access_id, da.permission, da.granted_date, u.name, u.email
       FROM document_access da JOIN users u ON u.user_id = da.user_id
       WHERE da.document_id = ? ORDER BY da.granted_date DESC`, [req.params.id]
    );
    res.json(rows);
  } catch { res.status(500).json({ message: "Could not load access list." }); }
});

app.post("/api/documents/:id/access", loggedIn, async (req, res) => {
  try {
    const doc = await canAccess(req.params.id, req.session.user);
    if (!doc || doc.my_permission !== "manage") return res.status(403).json({ message: "Only the owner or admin can grant access." });
    const email = (req.body.email || "").trim().toLowerCase();
    const permission = req.body.permission;
    if (!email || !["view", "download"].includes(permission))
      return res.status(400).json({ message: "Enter an email and choose view or download permission." });
    const [users] = await pool.query("SELECT user_id FROM users WHERE email = ?", [email]);
    if (!users.length) return res.status(404).json({ message: "No registered user found with that email." });
    if (users[0].user_id === doc.user_id) return res.status(400).json({ message: "The owner already has full access." });
    await pool.query(
      `INSERT INTO document_access (document_id, user_id, permission, granted_date)
       VALUES (?, ?, ?, NOW())
       ON DUPLICATE KEY UPDATE permission = VALUES(permission), granted_date = NOW()`,
      [req.params.id, users[0].user_id, permission]
    );
    res.json({ message: "Document access granted." });
  } catch { res.status(500).json({ message: "Could not grant access." }); }
});

app.delete("/api/access/:accessId", loggedIn, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT da.access_id, d.user_id AS owner_id
       FROM document_access da JOIN documents d ON d.document_id = da.document_id
       WHERE da.access_id = ?`, [req.params.accessId]
    );
    if (!rows.length) return res.status(404).json({ message: "Access record not found." });
    if (rows[0].owner_id !== req.session.user.user_id && !isAdmin(req))
      return res.status(403).json({ message: "Only the owner or admin can remove access." });
    await pool.query("DELETE FROM document_access WHERE access_id = ?", [req.params.accessId]);
    res.json({ message: "Access removed." });
  } catch { res.status(500).json({ message: "Could not remove access." }); }
});

app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE")
    return res.status(400).json({ message: "File must be 10 MB or smaller." });
  res.status(400).json({ message: err.message || "Something went wrong." });
});

app.listen(PORT, () => console.log(`Project running at http://localhost:${PORT}`));
