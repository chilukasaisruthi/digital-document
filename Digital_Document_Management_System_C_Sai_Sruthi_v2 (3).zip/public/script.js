const $ = id => document.getElementById(id);
let currentUser = null;
let categories = [];

function message(id, text, error = false) {
  $(id).textContent = text;
  $(id).className = "message " + (error ? "error" : "success");
}
async function api(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Request failed.");
  return data;
}
function showApp(user) {
  currentUser = user;
  $("authPanel").classList.add("hidden");
  $("appPanel").classList.remove("hidden");
  $("userArea").classList.remove("hidden");
  $("welcomeUser").textContent = "Hi, " + user.name;
  loadCategories().then(loadDocuments);
}
function showAuth() {
  currentUser = null;
  $("authPanel").classList.remove("hidden");
  $("appPanel").classList.add("hidden");
  $("userArea").classList.add("hidden");
}
$("loginTab").onclick = () => {
  $("loginForm").classList.remove("hidden"); $("registerForm").classList.add("hidden");
  $("loginTab").classList.add("active"); $("registerTab").classList.remove("active");
  message("authMessage", "");
};
$("registerTab").onclick = () => {
  $("registerForm").classList.remove("hidden"); $("loginForm").classList.add("hidden");
  $("registerTab").classList.add("active"); $("loginTab").classList.remove("active");
  message("authMessage", "");
};
$("loginForm").onsubmit = async e => {
  e.preventDefault();
  try {
    const data = await api("/api/login", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(Object.fromEntries(new FormData(e.target))) });
    showApp(data.user);
  } catch (err) { message("authMessage", err.message, true); }
};
$("registerForm").onsubmit = async e => {
  e.preventDefault();
  try {
    const data = await api("/api/register", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(Object.fromEntries(new FormData(e.target))) });
    showApp(data.user);
  } catch (err) { message("authMessage", err.message, true); }
};
$("logoutBtn").onclick = async () => {
  try { await api("/api/logout", { method: "POST" }); showAuth(); }
  catch (err) { alert(err.message); }
};

async function loadCategories() {
  try {
    categories = await api("/api/categories");
    $("categoryCount").textContent = categories.length;
    $("categorySelect").innerHTML = '<option value="">Select category</option>';
    $("filterSelect").innerHTML = '<option value="">All categories</option>';
    categories.forEach(c => {
      $("categorySelect").add(new Option(c.category_name, c.category_id));
      $("filterSelect").add(new Option(c.category_name, c.category_id));
    });
  } catch (err) { message("uploadMessage", err.message, true); }
}
async function loadDocuments() {
  try {
    const params = new URLSearchParams({search: $("searchInput").value, category: $("filterSelect").value});
    const docs = await api("/api/documents?" + params);
    $("totalCount").textContent = docs.length;
    if (!docs.length) {
      $("documentRows").innerHTML = '<tr><td colspan="6" class="empty">No documents found. Upload a document to get started.</td></tr>';
      return;
    }
    $("documentRows").innerHTML = docs.map(d => {
      const owner = d.user_id === currentUser.user_id || currentUser.role === "admin";
      const manage = d.my_permission === "manage";
      const download = ["download","manage"].includes(d.my_permission);
      return `<tr>
        <td><span class="doc-title">📄 ${escapeHTML(d.title)}</span></td>
        <td><span class="pill">${escapeHTML(d.category_name)}</span></td>
        <td>${escapeHTML(d.owner_name)}${owner ? " (You)" : ""}</td>
        <td>${new Date(d.upload_date).toLocaleDateString()}</td>
        <td>${escapeHTML(d.my_permission)}</td>
        <td>${download ? `<a class="action" href="/api/documents/${d.document_id}/download">Download</a>` : '<span class="muted">View only</span>'}
        ${manage ? `<button class="action" onclick="openAccess(${d.document_id})">Share</button><button class="action danger" onclick="deleteDoc(${d.document_id})">Delete</button>` : ""}</td>
      </tr>`;
    }).join("");
  } catch (err) { $("documentRows").innerHTML = `<tr><td colspan="6" class="empty">${escapeHTML(err.message)}</td></tr>`; }
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
$("uploadForm").onsubmit = async e => {
  e.preventDefault();
  const button = e.target.querySelector("button");
  button.disabled = true;
  try {
    const result = await api("/api/documents", {method:"POST", body:new FormData(e.target)});
    message("uploadMessage", result.message);
    e.target.reset();
    await loadDocuments();
  } catch (err) { message("uploadMessage", err.message, true); }
  finally { button.disabled = false; }
};
$("searchInput").addEventListener("input", loadDocuments);
$("filterSelect").addEventListener("change", loadDocuments);

async function deleteDoc(id) {
  if (!confirm("Delete this document permanently?")) return;
  try { const result = await api("/api/documents/" + id, {method:"DELETE"}); alert(result.message); loadDocuments(); }
  catch (err) { alert(err.message); }
}
async function openAccess(id) {
  $("accessForm").elements.document_id.value = id;
  $("accessModal").classList.remove("hidden");
  message("accessMessage", "");
  await loadAccessList(id);
}
async function loadAccessList(id) {
  try {
    const rows = await api(`/api/documents/${id}/access`);
    $("accessList").innerHTML = rows.length ? rows.map(r =>
      `<div class="access-row"><span>${escapeHTML(r.name)} · ${escapeHTML(r.email)} <b>(${escapeHTML(r.permission)})</b></span><button class="action danger" onclick="removeAccess(${r.access_id},${id})">Remove</button></div>`
    ).join("") : '<p class="muted">No one else has access yet.</p>';
  } catch (err) { $("accessList").textContent = err.message; }
}
$("accessForm").onsubmit = async e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target));
  const id = data.document_id;
  try {
    const result = await api(`/api/documents/${id}/access`, {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    message("accessMessage", result.message);
    e.target.elements.email.value = "";
    await loadAccessList(id);
  } catch (err) { message("accessMessage", err.message, true); }
};
async function removeAccess(accessId, docId) {
  try { await api("/api/access/" + accessId, {method:"DELETE"}); loadAccessList(docId); }
  catch (err) { message("accessMessage", err.message, true); }
}
$("closeModal").onclick = () => $("accessModal").classList.add("hidden");
$("accessModal").onclick = e => { if (e.target === $("accessModal")) $("accessModal").classList.add("hidden"); };

api("/api/me").then(data => data.user ? showApp(data.user) : showAuth()).catch(showAuth);
